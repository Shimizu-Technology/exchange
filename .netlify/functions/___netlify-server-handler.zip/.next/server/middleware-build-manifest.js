globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/c6108499b026e905.js",
    "static/chunks/82abf2d65f5428ae.js",
    "static/chunks/f2f58a7e93290fbb.js",
    "static/chunks/10cbf02e6fc36465.js",
    "static/chunks/turbopack-ca9b234626c0e5f9.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];