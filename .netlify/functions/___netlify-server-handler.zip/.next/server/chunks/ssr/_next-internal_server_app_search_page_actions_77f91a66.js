module.exports=[70965,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_search_page_actions_77f91a66.js.map