module.exports=[73808,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_messages_%5Bid%5D_page_actions_9a619a26.js.map