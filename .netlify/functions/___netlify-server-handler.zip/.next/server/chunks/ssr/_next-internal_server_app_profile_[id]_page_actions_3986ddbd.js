module.exports=[17413,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_profile_%5Bid%5D_page_actions_3986ddbd.js.map